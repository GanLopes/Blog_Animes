﻿namespace EstudioAnime.Models
{
    public class EstudiosModel
    {
        public string NomeEstudio { get; set; }
        public string Pais { get; set; }
        public string DataFundação { get; set; }
        public List<string> Animes { get; set; }
   
    }
}
