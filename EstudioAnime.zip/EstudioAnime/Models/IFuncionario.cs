﻿namespace EstudioAnime.Models
{
    public interface IFuncionario
    {
        string Login();
    }
}
