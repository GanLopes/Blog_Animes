﻿namespace EstudioAnime.Models
{
    public class AnimadoresModel : FuncionarioModel

    {
        public string Estilo { get; set; }
        public int AnosExperiencia { get; set; }

        // ======= CONSTRUTORES =========
        // Vazio
        public AnimadoresModel()
        {
        }

        // Com Herança
        public AnimadoresModel(string nome, string cargo, decimal salário, int idade, string estilo, int anosExperiencia)
        {
            Nome = nome;
            Cargo = cargo;
            Salário = salário;
            Idade = idade;
            Estilo = estilo;
            AnosExperiencia = anosExperiencia;
        }

        public string GetNome()
        {
            return Nome;
        }

        internal string TipoAnimacao()
        {
            switch (Estilo.ToLower())
            {
                case "ação":
                    return "Animação de cenas de ação";
                case "comédia":
                    return "Animação de comédia";
                case "aventura":
                    return "Animação de cenas de aventura";
                default:
                    return "Especializado em um estilo específico";
            }
        }

        public override string Login()
        {
            Console.WriteLine($" Animador {GetNome()} logado.");
            return "Animador " + GetNome() + " logado.";
        }
    }
}
