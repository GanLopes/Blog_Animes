﻿namespace EstudioAnime.Models
{
    public class FuncionarioModel : IFuncionario
    {
        protected string Nome { get; set; }
        public string Cargo { get; set; }
        public decimal Salário { get; set; }
        public int Idade { get; set; }

       // =========== MÉTODO DE SOBREESCRITA =========
       // Login
        public virtual string Login()
        {
            Console.WriteLine("Funcionário logado como funcionário comum.");
            return "Funcionário logado como funcionário comum";
        }
    }
}
