﻿namespace EstudioAnime.Models
{
    public class DiretoresModel : FuncionarioModel
    {

        public string Especializacao { get; set; }
        public int ProjetosConcluidos { get; set; }

        // ======= CONSTRUTORES =========
        // Vazio
        public DiretoresModel()
        {
        }

        // Com herança
        public DiretoresModel(string nome, string cargo, decimal salário, int idade, string especializacao, int projetosConcluidos)
        {
            Nome = nome;
            Cargo = cargo;
            Salário = salário;
            Idade = idade;
            Especializacao = especializacao;
            ProjetosConcluidos = projetosConcluidos;
        }

        public string GetNome()
        {
            return Nome;
        }

        public override string Login()
        {
            Console.WriteLine($" Diretor {GetNome()} logado.");
            return "Diretor " + GetNome() + " logado.";
        }
    }
}
