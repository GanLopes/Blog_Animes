﻿namespace EstudioAnime.Models
{
    public class AnimesModel
    {
        public string Titulo { get; set; }
        public int QuantidadeEp { get; set; }
        public string DataLancamento{ get; set; }




    }
}
