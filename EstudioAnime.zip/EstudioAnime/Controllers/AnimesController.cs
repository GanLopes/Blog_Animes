﻿using System.Diagnostics;
using EstudioAnime.Models;
using Microsoft.AspNetCore.Mvc;

namespace EstudioAnime.Controllers
{
    public class AnimesController : Controller
    {
        private readonly ILogger<AnimesController> _logger;

        public AnimesController(ILogger<AnimesController> logger)
        {
            _logger = logger;
        }


        public IActionResult Animes()
        {
            AnimesModel animes = new AnimesModel();

            animes.Titulo = "Naruto";
            animes.QuantidadeEp = 500;
            animes.DataLancamento = "2001";

            return View(animes);
        }


        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}