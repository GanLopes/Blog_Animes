﻿namespace EstudioAnime.Controllers
{
    internal class Funcionario
    {
    }
}